# have a thought to make an npm package 
that manage this.. 
seems small and great for a first package 

enum for type of notes 
templates or NO template 

psuedo code snippets  
guide qith questions

upocign features. 
track stuff like your numbers - # bugs fixed 
complexity measurements personal stats
put in the wiki - track comments as history 
maybe velocity
advanced can be to tap into azure dev ops with the open source package 
